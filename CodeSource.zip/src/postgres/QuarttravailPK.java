package postgres;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.sql.Date;
import java.util.Objects;

public class QuarttravailPK implements Serializable {
    private int idambulancier;
    private Date jour;

    @Column(name = "idambulancier", nullable = false)
    @Id
    public int getIdambulancier() {
        return idambulancier;
    }

    public void setIdambulancier(int idambulancier) {
        this.idambulancier = idambulancier;
    }

    @Column(name = "jour", nullable = false)
    @Id
    public Date getJour() {
        return jour;
    }

    public void setJour(Date jour) {
        this.jour = jour;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QuarttravailPK that = (QuarttravailPK) o;
        return idambulancier == that.idambulancier &&
                Objects.equals(jour, that.jour);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idambulancier, jour);
    }
}
