package postgres;

import java.util.Vector;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.loader.custom.sql.SQLQueryParser;

import java.util.ArrayList;

public class Main extends Application {




    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("javafx.fxml"));
        primaryStage.setTitle("Interface Base de données");
        Scene scene = new Scene(root, 300, 300);

        HBox hbox = new HBox();
        primaryStage.setScene(scene);
        primaryStage.show();




    }


    public static void main(String[] args) {

        launch(args);



    }
}
