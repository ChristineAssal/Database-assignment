package postgres;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class InterventionPK implements Serializable {
    private int idevenement;
    private int idambulancier;

    @Column(name = "idevenement", nullable = false)
    @Id
    public int getIdevenement() {
        return idevenement;
    }

    public void setIdevenement(int idevenement) {
        this.idevenement = idevenement;
    }

    @Column(name = "idambulancier", nullable = false)
    @Id
    public int getIdambulancier() {
        return idambulancier;
    }

    public void setIdambulancier(int idambulancier) {
        this.idambulancier = idambulancier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InterventionPK that = (InterventionPK) o;
        return idevenement == that.idevenement &&
                idambulancier == that.idambulancier;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idevenement, idambulancier);
    }
}
