package postgres;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class Ambulance {
    private String immatriculation;
    private int annee;
    private String manufacturier;
    private String modele;

    @Id
    @Column(name = "immatriculation", nullable = false, length = -1)
    public String getImmatriculation() {
        return immatriculation;
    }

    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }

    @Basic
    @Column(name = "annee", nullable = false)
    public int getAnnee() {
        return annee;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }

    @Basic
    @Column(name = "manufacturier", nullable = false, length = -1)
    public String getManufacturier() {
        return manufacturier;
    }

    public void setManufacturier(String manufacturier) {
        this.manufacturier = manufacturier;
    }

    @Basic
    @Column(name = "modele", nullable = false, length = -1)
    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ambulance ambulance = (Ambulance) o;
        return annee == ambulance.annee &&
                Objects.equals(immatriculation, ambulance.immatriculation) &&
                Objects.equals(manufacturier, ambulance.manufacturier) &&
                Objects.equals(modele, ambulance.modele);
    }

    @Override
    public int hashCode() {
        return Objects.hash(immatriculation, annee, manufacturier, modele);
    }
}
