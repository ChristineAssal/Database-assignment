package postgres;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@IdClass(QuarttravailPK.class)
public class Quarttravail {
    private int idambulancier;
    private Date jour;
    private double tempstravail;

    @Id
    @Column(name = "idambulancier", nullable = false)
    public int getIdambulancier() {
        return idambulancier;
    }

    public void setIdambulancier(int idambulancier) {
        this.idambulancier = idambulancier;
    }

    @Id
    @Column(name = "jour", nullable = false)
    public Date getJour() {
        return jour;
    }

    public void setJour(Date jour) {
        this.jour = jour;
    }

    @Basic
    @Column(name = "tempstravail", nullable = false, precision = 0)
    public double getTempstravail() {
        return tempstravail;
    }

    public void setTempstravail(double tempstravail) {
        this.tempstravail = tempstravail;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Quarttravail that = (Quarttravail) o;
        return idambulancier == that.idambulancier &&
                Objects.equals(jour, that.jour) &&
                Objects.equals(tempstravail, that.tempstravail);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idambulancier, jour, tempstravail);
    }
}
