package postgres;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Date;
import java.util.Objects;

@Entity
public class Ambulancier {
    private int idambulancier;
    private String nom;
    private String prenom;
    private double salairehoraire;
    private String numerotelephone;
    private Date datenaissance;
    private String numerocivique;
    private String rue;
    private String ville;
    private String province;
    private String codepostal;

    @Id
    @Column(name = "idambulancier", nullable = false)
    public int getIdambulancier() {
        return idambulancier;
    }

    public void setIdambulancier(int idambulancier) {
        this.idambulancier = idambulancier;
    }

    @Basic
    @Column(name = "nom", nullable = false, length = -1)
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Basic
    @Column(name = "prenom", nullable = false, length = -1)
    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    @Basic
    @Column(name = "salairehoraire", nullable = false)
    public double getSalairehoraire() {
        return salairehoraire;
    }

    public void setSalairehoraire(double salairehoraire) {
        this.salairehoraire = salairehoraire;
    }

    @Basic
    @Column(name = "numerotelephone", nullable = false, length = -1)
    public String getNumerotelephone() {
        return numerotelephone;
    }

    public void setNumerotelephone(String numerotelephone) {
        this.numerotelephone = numerotelephone;
    }

    @Basic
    @Column(name = "datenaissance", nullable = false)
    public Date getDatenaissance() {
        return datenaissance;
    }

    public void setDatenaissance(Date datenaissance) {
        this.datenaissance = datenaissance;
    }

    @Basic
    @Column(name = "numerocivique", nullable = false, length = -1)
    public String getNumerocivique() {
        return numerocivique;
    }

    public void setNumerocivique(String numerocivique) {
        this.numerocivique = numerocivique;
    }

    @Basic
    @Column(name = "rue", nullable = false, length = -1)
    public String getRue() {
        return rue;
    }

    public void setRue(String rue) {
        this.rue = rue;
    }

    @Basic
    @Column(name = "ville", nullable = false, length = -1)
    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    @Basic
    @Column(name = "province", nullable = false, length = -1)
    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    @Basic
    @Column(name = "codepostal", nullable = false, length = -1)
    public String getCodepostal() {
        return codepostal;
    }

    public void setCodepostal(String codepostal) {
        this.codepostal = codepostal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ambulancier that = (Ambulancier) o;
        return idambulancier == that.idambulancier &&
                Objects.equals(nom, that.nom) &&
                Objects.equals(prenom, that.prenom) &&
                Objects.equals(salairehoraire, that.salairehoraire) &&
                Objects.equals(numerotelephone, that.numerotelephone) &&
                Objects.equals(datenaissance, that.datenaissance) &&
                Objects.equals(numerocivique, that.numerocivique) &&
                Objects.equals(rue, that.rue) &&
                Objects.equals(ville, that.ville) &&
                Objects.equals(province, that.province) &&
                Objects.equals(codepostal, that.codepostal);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idambulancier, nom, prenom, salairehoraire, numerotelephone, datenaissance, numerocivique, rue, ville, province, codepostal);
    }
}
