package postgres;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
public class Evenement {
    private int idevenement;
    private Timestamp temps;
    private double duree;
    private double distance;
    private String typeevent;

    @Id
    @Column(name = "idevenement", nullable = false)
    public int getIdevenement() {
        return idevenement;
    }

    public void setIdevenement(int idevenement) {
        this.idevenement = idevenement;
    }

    @Basic
    @Column(name = "temps", nullable = false)
    public Timestamp getTemps() {
        return temps;
    }

    public void setTemps(Timestamp temps) {
        this.temps = temps;
    }

    @Basic
    @Column(name = "duree", nullable = false, precision = 0)
    public double getDuree() {
        return duree;
    }

    public void setDuree(double duree) {
        this.duree = duree;
    }

    @Basic
    @Column(name = "distance", nullable = false, precision = 0)
    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    @Basic
    @Column(name = "typeevent", nullable = false, length = -1)
    public String getTypeevent() {
        return typeevent;
    }

    public void setTypeevent(String typeevent) {
        this.typeevent = typeevent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Evenement evenement = (Evenement) o;
        return idevenement == evenement.idevenement &&
                Objects.equals(temps, evenement.temps) &&
                Objects.equals(duree, evenement.duree) &&
                Objects.equals(distance, evenement.distance) &&
                Objects.equals(typeevent, evenement.typeevent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idevenement, temps, duree, distance, typeevent);
    }
}
