package postgres;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class Pointdedepart {
    private int idpointdedepart;
    private String typeinstitut;
    private String pdnom;
    private String pdville;
    private String secteur;

    @Id
    @Column(name = "idpointdedepart", nullable = false)
    public int getIdpointdedepart() {
        return idpointdedepart;
    }

    public void setIdpointdedepart(int idpointdedepart) {
        this.idpointdedepart = idpointdedepart;
    }

    @Basic
    @Column(name = "typeinstitut", nullable = false, length = -1)
    public String getTypeinstitut() {
        return typeinstitut;
    }

    public void setTypeinstitut(String typeinstitut) {
        this.typeinstitut = typeinstitut;
    }

    @Basic
    @Column(name = "pdnom", nullable = false, length = -1)
    public String getPdnom() {
        return pdnom;
    }

    public void setPdnom(String pdnom) {
        this.pdnom = pdnom;
    }

    @Basic
    @Column(name = "pdville", nullable = false, length = -1)
    public String getPdville() {
        return pdville;
    }

    public void setPdville(String pdville) {
        this.pdville = pdville;
    }

    @Basic
    @Column(name = "secteur", nullable = false, length = -1)
    public String getSecteur() {
        return secteur;
    }

    public void setSecteur(String secteur) {
        this.secteur = secteur;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pointdedepart that = (Pointdedepart) o;
        return idpointdedepart == that.idpointdedepart &&
                Objects.equals(typeinstitut, that.typeinstitut) &&
                Objects.equals(pdnom, that.pdnom) &&
                Objects.equals(pdville, that.pdville) &&
                Objects.equals(secteur, that.secteur);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idpointdedepart, typeinstitut, pdnom, pdville, secteur);
    }
}
