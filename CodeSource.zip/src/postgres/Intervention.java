package postgres;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import java.util.Objects;

@Entity
@IdClass(InterventionPK.class)
public class Intervention {
    private int idevenement;
    private int idambulancier;

    @Id
    @Column(name = "idevenement", nullable = false)
    public int getIdevenement() {
        return idevenement;
    }

    public void setIdevenement(int idevenement) {
        this.idevenement = idevenement;
    }

    @Id
    @Column(name = "idambulancier", nullable = false)
    public int getIdambulancier() {
        return idambulancier;
    }

    public void setIdambulancier(int idambulancier) {
        this.idambulancier = idambulancier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Intervention that = (Intervention) o;
        return idevenement == that.idevenement &&
                idambulancier == that.idambulancier;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idevenement, idambulancier);
    }
}
