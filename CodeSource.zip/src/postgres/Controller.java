package postgres;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.SplitPane;

import javafx.scene.control.TextArea;
import javafx.scene.control.skin.SplitPaneSkin;
import javafx.scene.layout.VBox;
import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.cfg.Configuration;
import org.hibernate.loader.custom.sql.SQLQueryParser;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.internal.NativeQueryImpl;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.SqlResultSetMapping;
import javax.swing.plaf.basic.BasicBorders;
import javax.swing.text.html.parser.Entity;
import java.util.ArrayList;
import java.util.List;


public class Controller {
    @FXML
    private VBox fields;


    public void handleButtonAction(Event event) {

        Button source = (Button) event.getSource();
        Parent parent =  source.getParent().getParent();
        SplitPane splitPane = (SplitPane) parent;
        String id = parent.getId();
        ObservableList<Node> list =  splitPane.getItems();
        var text = (TextArea)list.get(1);
        text.setText(answerQuestion(Integer.parseInt(id)));


    }
    public  String hardcodeToString(List list) {
        String stringifiedObject = new String();
        for (int i = 0; i < list.size(); i++) {
            Object[] element = (Object[]) list.get(i);

            for (int j = 0; j < element.length; j++) {
                stringifiedObject +=   "| "+element[j].toString()+" |";
            }
            stringifiedObject += " \n";
        }
        return stringifiedObject;
    }

    public String answerQuestion(int num){
        String answer = new String();

        SessionFactory sf = new Configuration().configure().buildSessionFactory();
        Session session = sf.getCurrentSession();
        var tx = session.beginTransaction();
        String first = "";
        String second = "";
        var query = session.createSQLQuery("SET SEARCH_PATH to francis,ambulance;");
        query.executeUpdate();
        var dropRs = session.createSQLQuery("DROP TABLE IF EXISTS r1;\n" +
                "DROP TABLE IF EXISTS r2;\n" +
                "DROP TABLE IF EXISTS r3;\n" +
                "DROP TABLE IF EXISTS r4;\n" +
                "DROP TABLE IF EXISTS r5;\n" +
                "DROP TABLE IF EXISTS r6;\n" +
                "\n");
        dropRs.executeUpdate();
        switch(num) {
            case 1:
               first =
                                "SELECT idevenement INTO r2 FROM evenement WHERE typeevent='intoxication';  -- r1 and r2 in one line\n" +
                                "SELECT idevenement, immatriculation INTO r3 FROM intervention;\n" +
                                "SELECT DISTINCT immatriculation INTO r4 FROM r2 INNER JOIN r3 USING(idevenement);\n" +
                                "SELECT idpointdedepart, immatriculation INTO r5 FROM ambulance;\n" +
                                "SELECT idpointdedepart, pdnom INTO r6 FROM pointdedepart;";
                 second = " SELECT immatriculation, pdnom as nom_pointdedepart FROM r4 INNER JOIN r5 USING(immatriculation) INNER JOIN pointdedepart USING(idpointdedepart);";


                break;
            case 2:
                first =
                        "SELECT idambulancier, COUNT(idambulancier) INTO r1 FROM intervention GROUP BY idambulancier;\n" +
                        "SELECT idambulancier, nom, prenom INTO r2 FROM ambulancier;";
                second = "SELECT nom, prenom, count as nbintervention FROM r2 LEFT JOIN r1 USING(idambulancier) ORDER BY nom, prenom;";
                break;
            case 3:
                first = "SELECT idevenement, immatriculation, COUNT(idambulancier) INTO r1 FROM intervention GROUP BY idevenement, immatriculation;\n" +
                        "SELECT idevenement, COUNT(immatriculation) as nbambulance, SUM(count) as nbambulancier INTO r2 FROM r1 GROUP BY idevenement;\n" +
                        "SELECT idevenement, nbambulancier, nbambulance INTO r3 FROM r2 WHERE nbambulance > 1;\n" +
                        "SELECT idevenement, date(temps) as date_, typeevent INTO r4 FROM evenement;";
                second = "SELECT typeevent, date_, nbambulancier, nbambulance FROM r3 INNER JOIN r4 USING(idevenement);";
                break;
            case 4:
                first = "SELECT idambulancier, tempstravail INTO r2 FROM quarttravail WHERE jour BETWEEN '2021-04-19' AND '2021-04-25'; -- r1 et r2 en une ligne\n" +
                        "SELECT idambulancier, SUM(tempstravail) as heuressemaine19avril INTO r3 FROM r2 GROUP BY idambulancier;\n" +
                        "SELECT idambulancier, nom, prenom INTO r4 FROM ambulancier;";

                second = "SELECT nom, prenom, heuressemaine19avril FROM r4 LEFT JOIN r3 USING(idambulancier) ORDER BY nom, prenom;";
                break;

        }
        session.createSQLQuery(first).executeUpdate();
        List<String> list = session.createSQLQuery(second).list();
        dropRs = session.createSQLQuery("DROP TABLE IF EXISTS r1;\n" +
               "DROP TABLE IF EXISTS r2;\n" +
               "DROP TABLE IF EXISTS r3;\n" +
                "DROP TABLE IF EXISTS r4;\n" +
               "DROP TABLE IF EXISTS r5;\n" +
                "DROP TABLE IF EXISTS r6;\n" +
                "\n");
        dropRs.executeUpdate();
        tx.commit();
        session.close();
       return hardcodeToString(list);
    };
}
